package com.example.analysis;


import java.util.ArrayList;
import java.util.List;

public class SignalGenerator {
    public static List<Signal> analyze(List<AggregatedData> data) {
        List<Signal> signals = new ArrayList<>();
        for (AggregatedData entry : data) {
            String recommendation = entry.getAvgClose() > entry.getMaxHigh() * 0.95
                    ? "SELL"
                    : entry.getAvgClose() < entry.getMinLow() * 1.05
                    ? "BUY"
                    : "HOLD";
            signals.add(new Signal(entry.getSymbol(), recommendation));
        }
        return signals;
    }
}
