package com.example.analysis;
import io.micronaut.http.MediaType;
import io.micronaut.runtime.Micronaut;
import io.micronaut.http.annotation.*;
import io.micronaut.http.client.annotation.Client;
import jakarta.inject.Inject;

import java.util.List;

@Controller("/signals")
public class SignalController {

    @Inject
    StorageClient storageClient;

    @Get("/")
    public List<Signal> getSignals() {
        List<AggregatedData> data = storageClient.fetchLatest();
        return SignalGenerator.analyze(data);
    }
    @Get
    @Produces(MediaType.TEXT_PLAIN)
    public String index() {
        return "Hello World";
    }


}

@Client("http://data-storage-service:8081")
interface StorageClient {
    @Get("/data/latest")
    List<AggregatedData> fetchLatest();
}
