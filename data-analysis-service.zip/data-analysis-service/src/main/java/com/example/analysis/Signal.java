package com.example.analysis;

public class Signal {
    private String symbol;
    private String recommendation;

    public Signal(String symbol, String recommendation) {
        this.symbol = symbol;
        this.recommendation = recommendation;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getRecommendation() {
        return recommendation;
    }
}
