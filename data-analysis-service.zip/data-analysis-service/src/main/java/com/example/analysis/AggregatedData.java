package com.example.analysis;

import java.time.LocalDateTime;

public class AggregatedData {

    private Long id;

    private String symbol;
    private LocalDateTime timestamp;
    private Double avgClose;
    private Double maxHigh;
    private Double minLow;

    // Getters and setters
    public Long getId() { return id; }
    public String getSymbol() { return symbol; }
    public void setSymbol(String symbol) { this.symbol = symbol; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public Double getAvgClose() { return avgClose; }
    public void setAvgClose(Double avgClose) { this.avgClose = avgClose; }
    public Double getMaxHigh() { return maxHigh; }
    public void setMaxHigh(Double maxHigh) { this.maxHigh = maxHigh; }
    public Double getMinLow() { return minLow; }
    public void setMinLow(Double minLow) { this.minLow = minLow; }
}