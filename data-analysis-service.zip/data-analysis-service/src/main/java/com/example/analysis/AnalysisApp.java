package com.example.analysis;


import io.micronaut.runtime.Micronaut;

public class AnalysisApp {
    public static void main(String[] args) {
        Micronaut.run(AnalysisApp.class, args);
    }
}
